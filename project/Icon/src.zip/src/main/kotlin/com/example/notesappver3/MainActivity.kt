package com.example.notesappver3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
